import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  ArrowUpRight, 
  ExternalLink, 
  Plus, 
  Terminal 
} from 'lucide-react';

// --- Gemini API Configuration ---
// 注意：在 Zeabur 環境變數中設定 VITE_GEMINI_API_KEY
const apiKey = import.meta.env.VITE_GEMINI_API_KEY || ""; 

// --- Custom Hook for Mouse Position ---
const useMousePosition = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const updateMousePosition = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', updateMousePosition);
    return () => window.removeEventListener('mousemove', updateMousePosition);
  }, []);

  return mousePosition;
};

// --- Components ---

const CustomCursor = () => {
  const { x, y } = useMousePosition();
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const handleMouseOver = (e) => {
      // 判斷是否為可互動元素
      if (
        e.target.tagName === 'A' || 
        e.target.tagName === 'BUTTON' || 
        e.target.tagName === 'INPUT' ||
        e.target.closest('a') || 
        e.target.closest('button') ||
        e.target.closest('.interactive-area')
      ) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };
    window.addEventListener('mouseover', handleMouseOver);
    return () => window.removeEventListener('mouseover', handleMouseOver);
  }, []);

  return (
    <>
      {/* Crosshair Lines - Full Screen (Hidden on mobile) */}
      <div 
        className="fixed top-0 left-0 w-full h-[1px] bg-blue-600/30 pointer-events-none z-40 hidden md:block mix-blend-multiply"
        style={{ transform: `translateY(${y}px)` }}
      />
      <div 
        className="fixed top-0 left-0 h-full w-[1px] bg-blue-600/30 pointer-events-none z-40 hidden md:block mix-blend-multiply"
        style={{ transform: `translateX(${x}px)` }}
      />
      
      {/* Cursor Label */}
      <div 
        className="fixed top-2 left-2 pointer-events-none z-50 hidden md:block"
        style={{ 
          transform: `translate(${x + 10}px, ${y + 10}px)`,
        }}
      >
         <div className="bg-blue-600 text-white text-[10px] font-mono px-1 py-0.5 shadow-sm">
            X:{x} Y:{y} {isHovering ? '[ACTIVE]' : ''}
         </div>
      </div>
    </>
  );
};

const Navbar = () => (
  <nav className="fixed top-0 left-0 w-full z-40 pointer-events-none">
    {/* LOGO */}
    <div className="absolute top-6 left-6 font-bold tracking-tight text-xl pointer-events-auto cursor-pointer text-black z-50">
      玉子藝術工作室
    </div>
    <div className="absolute top-6 right-6 flex flex-col items-end gap-1 pointer-events-auto mix-blend-difference text-white z-50">
       {['ABOUT', 'EXP.', 'AI-LAB', 'WORKS'].map((item, i) => (
         <a key={i} href={`#${item.toLowerCase().replace('.', '')}`} className="text-xs font-mono hover:bg-blue-600 hover:text-white px-1 transition-colors">
           0{i+1} / {item}
         </a>
       ))}
    </div>
  </nav>
);

const SectionLabel = ({ num, text }) => (
  <div className="absolute -left-4 top-0 transform -rotate-90 origin-top-right text-[10px] font-mono tracking-widest text-neutral-400 select-none">
    {num} — {text}
  </div>
);

const Hero = () => {
  return (
    <section className="relative min-h-screen flex flex-col justify-between p-6 md:p-12 bg-[#F2F2F2] text-black overflow-hidden selection:bg-blue-600 selection:text-white">
      {/* Grid Lines */}
      <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: 'linear-gradient(#e5e5e5 1px, transparent 1px), linear-gradient(90deg, #e5e5e5 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>

      <div className="mt-24 relative z-10">
        <h2 className="font-mono text-xs md:text-sm mb-4 text-blue-600 tracking-wider">
          ● STATUS: ONLINE
        </h2>
        <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-[0.9] mb-8">
          思考是藝術<span className="text-blue-600">.</span><br/>
          <span className="font-light text-neutral-400 block mt-2 text-4xl md:text-6xl">讓品牌看見是技術</span>
        </h1>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-end relative z-10">
        <div className="max-w-md font-mono text-xs md:text-sm leading-relaxed text-neutral-600 bg-[#F2F2F2]/80 backdrop-blur-sm p-2 md:p-0">
          <p className="mb-4 text-black font-bold">[ INFO ]</p>
          <p>SU, LING-YU (LYNN)</p>
          <p>ART DIRECTOR / VISUAL DESIGNER</p>
          <p>BASED IN TAIPEI & TAICHUNG</p>
          <p>EST. 2025</p>
        </div>
        
        <div className="mt-8 md:mt-0 animate-spin-slow">
           <div className="w-24 h-24 rounded-full border border-black flex items-center justify-center hover:bg-black hover:text-white transition-colors cursor-pointer">
              <ArrowRight className="transform rotate-45" />
           </div>
        </div>
      </div>

      {/* Decorative Crop Marks */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t border-l border-black"></div>
      <div className="absolute top-0 right-0 w-4 h-4 border-t border-r border-black"></div>
      <div className="absolute bottom-0 left-0 w-4 h-4 border-b border-l border-black"></div>
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b border-r border-black"></div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-32 px-6 md:px-12 bg-white text-black relative border-t border-black">
      <div className="max-w-screen-xl mx-auto">
        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 md:col-span-4 relative">
             <div className="w-full aspect-[3/4] bg-neutral-100 grayscale contrast-125 relative overflow-hidden group">
                <div className="absolute inset-0 flex items-center justify-center font-bold text-9xl text-neutral-200 group-hover:text-blue-600 transition-colors duration-500 select-none">
                   L
                </div>
                {/* Overlay Text */}
                <div className="absolute bottom-2 left-2 font-mono text-[10px] bg-white px-1 border border-neutral-200">IMG_001.RAW</div>
             </div>
             <div className="mt-4 flex justify-between font-mono text-xs text-neutral-500">
               <span>FIG. 1 — PORTRAIT</span>
               <span>(1:1.4)</span>
             </div>
          </div>

          <div className="col-span-12 md:col-span-7 md:col-start-6 flex flex-col justify-center">
            <div className="relative">
              <SectionLabel num="01" text="ABOUT" />
              
              <h3 className="text-3xl md:text-5xl font-bold mb-12 leading-tight tracking-tight">
                The Philosophy <br/>
                <span className="text-neutral-400">of Visuals.</span>
              </h3>
            </div>
            
            <div className="space-y-8 text-base md:text-lg leading-relaxed text-neutral-800 text-justify">
              <p>
                主修視覺設計，畢業於中央大學哲學系。這不是一條筆直的路，而是一次思想的折返跑。
              </p>
              <p>
                從 TBWA 到 BBDO，在 4A 廣告的戰場上，我學會了如何用畫面說謊，也學會了如何用畫面說實話。
                如同藤井保（Tamotsu Fujii）的攝影，我追求的不是張揚的噪點，而是靜默中的高訊噪比。
              </p>
              <p className="font-bold border-l-4 border-blue-600 pl-4 py-1 bg-blue-50/50">
                設計不只是排列組合，它是對混亂世界的整理術。
              </p>
            </div>

            <div className="mt-16 grid grid-cols-2 gap-8 border-t border-neutral-200 pt-8 font-mono text-xs">
              <div>
                 <h4 className="mb-3 bg-black text-white inline-block px-1">EDUCATION</h4>
                 <ul className="space-y-2 text-neutral-600">
                   <li className="flex justify-between border-b border-dashed border-neutral-200 pb-1">
                     <span>NCU Philosophy, M.A.</span>
                     <span>2025</span>
                   </li>
                   <li className="flex justify-between border-b border-dashed border-neutral-200 pb-1">
                     <span>OIT Commercial Design, B.A.</span>
                     <span>2014</span>
                   </li>
                 </ul>
              </div>
              <div>
                 <h4 className="mb-3 bg-black text-white inline-block px-1">CERTIFICATION</h4>
                 <ul className="space-y-2 text-neutral-600">
                   <li className="border-b border-dashed border-neutral-200 pb-1">Ad Design Level C</li>
                   <li className="border-b border-dashed border-neutral-200 pb-1">Photoshop ACA Intl.</li>
                 </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ExperienceRow = ({ role, company, year, type }) => (
  <div className="group relative border-b border-black py-6 hover:bg-neutral-50 transition-colors cursor-default">
    <div className="grid grid-cols-12 items-baseline gap-4">
      <div className="col-span-12 md:col-span-2 font-mono text-xs text-neutral-400">{year}</div>
      <div className="col-span-12 md:col-span-4 text-xl font-bold group-hover:text-blue-600 transition-colors">{company}</div>
      <div className="col-span-12 md:col-span-4 text-lg">{role}</div>
      <div className="col-span-12 md:col-span-2 md:text-right font-mono text-xs text-neutral-400">[{type}]</div>
    </div>
    <div className="hidden group-hover:block absolute right-4 top-1/2 transform -translate-y-1/2">
       <ArrowUpRight className="text-blue-600" size={24} />
    </div>
  </div>
);

const Experience = () => {
  const jobs = [
    { year: "2022-2025", company: "言形創意整合行銷", role: "Art Director", type: "Full-time" },
    { year: "2021-2022", company: "TBWA (李岱艾)", role: "Associate AD", type: "4A Agency" },
    { year: "2019-2021", company: "BBDO Taiwan", role: "Associate AD", type: "4A Agency" },
    { year: "2017-2019", company: "橘子磨坊", role: "Visual Designer", type: "Digital" },
    { year: "2016-2017", company: "春樹科技", role: "Digital Design", type: "Digital" },
  ];

  return (
    <section id="exp" className="py-32 px-6 md:px-12 bg-[#F2F2F2] text-black min-h-screen flex flex-col justify-center">
      <div className="max-w-screen-xl mx-auto w-full">
        <div className="mb-16 flex items-end justify-between border-b-4 border-black pb-4">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tighter">EXPERIENCE</h2>
          <span className="font-mono text-xs md:text-sm mb-1 block text-neutral-500">CAREER_HISTORY_LOG</span>
        </div>
        
        <div className="w-full">
          <div className="grid grid-cols-12 gap-4 mb-4 font-mono text-xs text-neutral-500 uppercase tracking-widest px-2 md:px-0">
             <div className="hidden md:block col-span-2">Period</div>
             <div className="col-span-12 md:col-span-4">Agency</div>
             <div className="hidden md:block col-span-4">Position</div>
             <div className="hidden md:block col-span-2 text-right">Type</div>
          </div>
          {jobs.map((job, index) => (
            <ExperienceRow key={index} {...job} />
          ))}
        </div>
        
        <div className="mt-16 p-8 bg-white border border-neutral-200 relative overflow-hidden group">
           <div className="absolute top-0 right-0 bg-blue-600 text-white text-xs px-2 py-1 font-mono group-hover:bg-black transition-colors">SKILL_SET</div>
           <div className="flex flex-wrap gap-2 md:gap-4 font-mono text-sm pt-4">
              {['Photoshop', 'Illustrator', 'After Effects', 'Figma', 'UI/UX', 'Printing', 'Editorial'].map(skill => (
                 <span key={skill} className="border border-neutral-300 px-4 py-2 rounded-full hover:bg-black hover:border-black hover:text-white transition-colors cursor-default">
                   {skill}
                 </span>
              ))}
           </div>
        </div>
      </div>
    </section>
  );
};

const CreativeLab = () => {
  const [activeTab, setActiveTab] = useState('concept');
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState('');
  const [error, setError] = useState('');
  
  const callGemini = async (prompt) => {
    setIsLoading(true);
    setResult('');
    setError('');
    
    // 檢查 API Key 是否存在
    if (!apiKey) {
        setError("SYSTEM ERROR: API KEY NOT FOUND. PLEASE CONFIGURE ENV.");
        setIsLoading(false);
        return;
    }

    try {
       const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }]
          })
        }
      );
      
      if (!response.ok) {
        throw new Error('API request failed');
      }

      const data = await response.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if(text) {
        setResult(text);
      } else {
        setError("NO DATA RETURNED.");
      }
    } catch (e) {
      console.error(e);
      setError("ERROR: CONNECTION_REFUSED. PLEASE RETRY.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleExec = () => {
    if (!inputValue.trim()) return;
    const prompt = activeTab === 'concept' 
      ? `Act as a conceptual artist/designer (Aaron Nieh style). Deconstruct the concept of "${inputValue}" into: 1. Essence (Abstract), 2. Visual Form (Geometric/Color), 3. Statement (Slogan). Output in Traditional Chinese.`
      : `Act as Lynn Su. Answer this design question with philosophical depth and minimalist pragmaticism: "${inputValue}". Output in Traditional Chinese.`;
    callGemini(prompt);
  };

  return (
    <section id="ai-lab" className="py-32 px-6 md:px-12 bg-blue-600 text-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 p-4 opacity-10 font-mono text-9xl font-bold select-none pointer-events-none">
        AI
      </div>

      <div className="max-w-screen-xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 relative z-10">
        <div>
           <h2 className="text-6xl md:text-8xl font-bold tracking-tighter mb-8">
             AI_LAB<span className="animate-pulse text-black">_</span>
           </h2>
           <div className="font-mono text-sm md:text-base max-w-md leading-relaxed mb-12 opacity-80 border-l border-white/30 pl-4">
             <p>[ CONCEPT GENERATOR V1.0 ]</p>
             <p>輸入參數，解構意義。</p>
             <p>將抽象思維轉化為視覺訊號。</p>
           </div>
           
           <div className="flex gap-4 mb-8 interactive-area">
             <button 
               onClick={() => { setActiveTab('concept'); setResult(''); setError(''); }}
               className={`px-4 py-2 font-mono text-sm border transition-all ${activeTab === 'concept' ? 'bg-white text-blue-600 border-white' : 'border-white/30 text-white hover:bg-white/10'}`}
             >
               MODE A: DISTILL
             </button>
             <button 
               onClick={() => { setActiveTab('ask'); setResult(''); setError(''); }}
               className={`px-4 py-2 font-mono text-sm border transition-all ${activeTab === 'ask' ? 'bg-white text-blue-600 border-white' : 'border-white/30 text-white hover:bg-white/10'}`}
             >
               MODE B: DIALOGUE
             </button>
           </div>

           <div className="flex flex-col gap-4">
             <div className="relative">
                <input 
                  type="text" 
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="INPUT_DATA..."
                  className="w-full bg-transparent border-b-2 border-white text-2xl md:text-4xl py-4 focus:outline-none placeholder-white/30 font-bold focus:border-black transition-colors"
                  onKeyDown={(e) => e.key === 'Enter' && handleExec()}
                />
                <div className="absolute right-0 bottom-4 text-xs font-mono opacity-50">
                   {inputValue.length} CHARS
                </div>
             </div>
             <button 
               onClick={handleExec}
               disabled={isLoading}
               className="self-start mt-4 bg-black text-white px-8 py-3 font-mono text-xs hover:bg-white hover:text-black transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
             >
               {isLoading ? 'PROCESSING...' : 'EXECUTE COMMAND'}
             </button>
           </div>
        </div>

        <div className="relative min-h-[300px] bg-white text-black p-8 font-mono text-sm overflow-hidden shadow-2xl">
           <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 via-transparent to-blue-600"></div>
           <div className="absolute top-4 right-4 text-[10px] text-neutral-400">OUTPUT_TERMINAL</div>
           <div className="absolute top-4 left-4 flex gap-1">
              <div className="w-2 h-2 rounded-full bg-red-500"></div>
              <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
           </div>
           
           <div className="mt-8 h-full overflow-y-auto max-h-[400px]">
             {isLoading ? (
               <div className="flex flex-col items-center justify-center h-48 text-neutral-400 animate-pulse space-y-2">
                 <Terminal size={32} />
                 <span>COMPUTING...</span>
               </div>
             ) : error ? (
                <div className="text-red-500 font-bold">{error}</div>
             ) : result ? (
               <div className="whitespace-pre-wrap leading-relaxed animate-fade-in text-base">
                 {result}
                 <span className="inline-block w-2 h-4 bg-black ml-1 animate-pulse align-middle"></span>
               </div>
             ) : (
               <div className="h-48 flex items-center justify-center text-neutral-300">
                 WAITING FOR INPUT...
               </div>
             )}
           </div>
           
           {/* Decorative Barcode */}
           <div className="absolute bottom-4 right-4 flex gap-0.5 h-4 opacity-50">
              {[...Array(20)].map((_,i) => (
                <div key={i} className={`w-${Math.random() > 0.5 ? '1' : '2'} bg-black`}></div>
              ))}
           </div>
        </div>
      </div>
    </section>
  );
};

const Works = () => {
  return (
    <section id="works" className="py-32 px-6 md:px-12 bg-white text-black border-t border-black">
      <div className="max-w-screen-xl mx-auto">
         <div className="flex justify-between items-end mb-12">
            <h2 className="text-5xl md:text-7xl font-bold tracking-tighter">SELECTED<br/>WORKS</h2>
            <a href="https://reurl.cc/mYpWn1" target="_blank" rel="noreferrer" className="hidden md:flex items-center gap-2 font-mono text-xs bg-black text-white px-4 py-2 hover:bg-blue-600 transition-colors">
               FULL PORTFOLIO <ExternalLink size={12}/>
            </a>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-neutral-200 border border-neutral-200">
            {[
              { title: "Project Alpha", cat: "Branding", id: "01" },
              { title: "Neon City", cat: "Editorial", id: "02" },
              { title: "Silence", cat: "Photography", id: "03" },
              { title: "Echo", cat: "Web Design", id: "04" }
            ].map((item) => (
              <div key={item.id} className="bg-white p-12 aspect-square flex flex-col justify-between group hover:bg-neutral-50 transition-colors relative overflow-hidden cursor-pointer">
                 <div className="absolute top-4 left-4 font-mono text-xs text-neutral-400">{item.id}</div>
                 <div className="w-full h-full absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none">
                    <h3 className="text-9xl font-bold text-neutral-100">{item.id}</h3>
                 </div>
                 <div className="z-10 mt-auto">
                    <h3 className="text-3xl font-bold mb-2 group-hover:text-blue-600 transition-colors">{item.title}</h3>
                    <p className="font-mono text-xs text-neutral-500 uppercase tracking-widest">{item.cat}</p>
                 </div>
                 <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity text-blue-600">
                    <Plus size={24}/>
                 </div>
              </div>
            ))}
         </div>
         
         <div className="mt-12 md:hidden">
            <a href="https://reurl.cc/mYpWn1" target="_blank" rel="noreferrer" className="w-full flex items-center justify-center gap-2 font-mono text-xs bg-black text-white px-4 py-4">
               FULL PORTFOLIO <ExternalLink size={12}/>
            </a>
         </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-black text-white py-24 px-6 md:px-12 font-mono text-xs md:text-sm">
      <div className="max-w-screen-xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-end gap-12">
         <div>
            <div className="mb-8 text-neutral-500 tracking-widest">[ CONTACT_INFO ]</div>
            <a href="mailto:linyudesign@gmail.com" className="text-2xl md:text-4xl block hover:text-blue-600 transition-colors mb-2 font-sans font-bold">
               linyudesign@gmail.com
            </a>
            <p className="text-neutral-400">T. 0982-787-797</p>
         </div>

         <div className="text-right">
            <p className="mb-2">© 2025 YUZI ART STUDIO</p>
            <p className="text-neutral-500">DESIGNED BY LYNN SU</p>
            <div className="flex justify-end gap-2 mt-4">
               <div className="w-3 h-3 bg-cyan-400 rounded-full"></div>
               <div className="w-3 h-3 bg-magenta-500 rounded-full"></div>
               <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
               <div className="w-3 h-3 bg-black border border-white rounded-full"></div>
            </div>
         </div>
      </div>
    </footer>
  );
};

const App = () => {
  return (
    <div className="font-sans selection:bg-blue-600 selection:text-white">
      <CustomCursor />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Experience />
        <CreativeLab />
        <Works />
      </main>
      <Footer />
    </div>
  );
};

export default App;